# Mental Health Survey - Exploratory Data Analysis

This repo contains a mini project of exploratory data analysis (EDA) base on a survey about mental health in tech found [here](https://www.kaggle.com/osmi/mental-health-in-tech-survey).



